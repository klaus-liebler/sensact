#pragma once
#include <sensacthal.hpp>
#include <common.hpp>
#include <stm32f4xx_hal.h>